export enum Role {
  User = 2,
  Admin = 1
}