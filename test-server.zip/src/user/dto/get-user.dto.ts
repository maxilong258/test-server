export interface getUserDto {
  page: number
  limit? : number
  username: string
  role?: number
  gender?: number
}